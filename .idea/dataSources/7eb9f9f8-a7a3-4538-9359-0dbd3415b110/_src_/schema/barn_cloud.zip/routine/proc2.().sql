CREATE PROCEDURE `proc2`(OUT `s` INT(11))
  select count(*) into s from user