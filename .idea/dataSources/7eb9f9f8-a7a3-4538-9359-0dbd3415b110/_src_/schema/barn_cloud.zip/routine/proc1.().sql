CREATE PROCEDURE `proc1`(OUT `s` INT(11))
  begin
	select count(*) into s from user;
end